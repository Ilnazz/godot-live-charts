namespace GodotPlugins.LiveCharts;

public partial class CartesianChart : LiveChartsCore.SkiaSharpView.Godot.CartesianChart;