namespace GodotPlugins.LiveCharts;

public partial class PieChart : LiveChartsCore.SkiaSharpView.Godot.PieChart;