namespace GodotPlugins.LiveCharts;

public partial class PolarChart : LiveChartsCore.SkiaSharpView.Godot.PolarChart;