namespace GodotPlugins.LiveCharts;

public partial class GeoMap : LiveChartsCore.SkiaSharpView.Godot.GeoMap;